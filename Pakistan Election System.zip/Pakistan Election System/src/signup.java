
public class signup {
      private int resultId;
    private String candidateId;
    private int votes;
    private String electionId;

    public signup() {
    }

    
    public signup(int resultId, String candidateId, int votes, String electionId) {
        this.resultId = resultId;
        this.candidateId = candidateId;
        this.votes = votes;
        this.electionId = electionId;
    }

    public int getResultId() {
        return resultId;
    }

    public void setResultId(int resultId) {
        this.resultId = resultId;
    }

    public String getCandidateId() {
        return candidateId;
    }

    public void setCandidateId(String candidateId) {
        this.candidateId = candidateId;
    }

    public int getVotes() {
        return votes;
    }

    public void setVotes(int votes) {
        this.votes = votes;
    }

    public String getElectionId() {
        return electionId;
    }

    public void setElectionId(String electionId) {
        this.electionId = electionId;
    }
    
}
