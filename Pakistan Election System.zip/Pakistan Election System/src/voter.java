package pakistan.election.system;

public class voter {
    
    private String voterId;
    private String name;
    private boolean hasVoted;

        public voter(String voterId, String name, boolean hasVoted) {
            this.voterId = voterId;
            this.name = name;
            this.hasVoted = hasVoted;
        }

        public String getVoterId() {
            return voterId;
        }

        public void setVoterId(String voterId) {
            this.voterId = voterId;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public boolean isHasVoted() {
            return hasVoted;
        }

        public void setHasVoted(boolean hasVoted) {
            this.hasVoted = hasVoted;
        }

   
}

