
package pakistan.election.system;



public class result {
    
    
    public result(){
        
    }
    
}
