package pakistan.election.system;


import javax.swing.*;

public class vote extends JFrame {
    
    public vote(){
    }

   
}

