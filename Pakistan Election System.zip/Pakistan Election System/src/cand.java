package pakistan.election.system;
public class cand {
   
    private String candidateId;
    private String name;
    private int voteCount;

    public cand() {
    }

    
    public cand(String candidateId, String name, int voteCount) {
        this.candidateId = candidateId;
        this.name = name;
        this.voteCount = voteCount;
    }

    public String getCandidateId() {
        return candidateId;
    }

    public void setCandidateId(String candidateId) {
        this.candidateId = candidateId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getVoteCount() {
        return voteCount;
    }

    public void setVoteCount(int voteCount) {
        this.voteCount = voteCount;
    }

    
}


