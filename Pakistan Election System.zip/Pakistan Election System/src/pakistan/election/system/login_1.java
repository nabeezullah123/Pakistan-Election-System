package pakistan.election.system;


   


public class login_1 {
  
    private String username;
    private String password; // In production, always hash passwords!
    
    
public login_1() {
        System.out.println("login constructor called.");
    }
    public login_1(String username, String password) {
        this.username = username;
        this.password = password;
    }

    // Getters and setters
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    
}


