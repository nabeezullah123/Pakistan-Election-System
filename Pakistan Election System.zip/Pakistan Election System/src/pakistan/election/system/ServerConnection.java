
package pakistan.election.system;

import java.net.Socket;
import java.io.*;

public class ServerConnection {
    public static Socket socket;
    public static PrintWriter out;
    public static BufferedReader in;
    public static void ConnectToServer(){
       try{
        socket = new Socket("localhost",12345);
        out = new PrintWriter(socket.getOutputStream(),true);
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        System.out.println("Connect to the server successfully");
       }catch(Exception e){
           System.out.println(e.getMessage());
       }
    }
    public static void CloseConnection(){
        try{
            out.close();
            in.close();
            socket.close();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
}
