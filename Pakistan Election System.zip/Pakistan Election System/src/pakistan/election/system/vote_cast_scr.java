package pakistan.election.system;

import javax.swing.JOptionPane;

import pakistan.election.system.ServerConnection;


public class  vote_cast_scr  extends javax.swing.JFrame {   
  
 public vote_cast_scr(){
        initComponents();
    }


 


   
  
  
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        votebtn = new javax.swing.JButton();
        msg = new javax.swing.JLabel();
        txtVoterID = new javax.swing.JTextField();
        txtSeatNo = new javax.swing.JTextField();
        txtCandidateName = new javax.swing.JTextField();
        sno = new javax.swing.JLabel();
        cn = new javax.swing.JLabel();
        VID = new javax.swing.JLabel();
        txtPartyName3 = new javax.swing.JTextField();
        pname = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(0, 204, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Cast your Vote");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 0, 308, 30));

        votebtn.setBackground(new java.awt.Color(0, 204, 0));
        votebtn.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        votebtn.setText("VOTE");
        votebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                votebtnActionPerformed(evt);
            }
        });
        jPanel2.add(votebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 200, 250, 50));

        msg.setForeground(new java.awt.Color(255, 0, 0));
        msg.setText("CLICK HERE TO VOTE YOUR FAVOURITE CANDIDATE");
        jPanel2.add(msg, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 150, 330, 40));

        txtVoterID.setBackground(new java.awt.Color(0, 204, 255));
        txtVoterID.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtVoterID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtVoterIDActionPerformed(evt);
            }
        });
        jPanel2.add(txtVoterID, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 63, 240, -1));

        txtSeatNo.setBackground(new java.awt.Color(0, 204, 255));
        txtSeatNo.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtSeatNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSeatNoActionPerformed(evt);
            }
        });
        jPanel2.add(txtSeatNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 110, 240, -1));

        txtCandidateName.setBackground(new java.awt.Color(0, 204, 255));
        txtCandidateName.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtCandidateName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCandidateNameActionPerformed(evt);
            }
        });
        jPanel2.add(txtCandidateName, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 110, 237, -1));

        sno.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        sno.setText("Seatno");
        jPanel2.add(sno, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 90, -1, -1));

        cn.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        cn.setText("Candidate Name");
        jPanel2.add(cn, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 90, -1, -1));

        VID.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        VID.setText("Voter ID");
        jPanel2.add(VID, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 46, -1, 20));

        txtPartyName3.setBackground(new java.awt.Color(0, 204, 255));
        txtPartyName3.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txtPartyName3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPartyName3ActionPerformed(evt);
            }
        });
        jPanel2.add(txtPartyName3, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 60, 240, -1));

        pname.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        pname.setText("Party Name");
        jPanel2.add(pname, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 40, -1, 20));

        jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\PC\\Desktop\\VOTE 2.jpg")); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 592, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(6, 6, 6))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void votebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_votebtnActionPerformed

     


       
        String voterId =txtVoterID.getText().trim();
        String partyName = txtPartyName3.getText().trim();
        String CandidateName = txtCandidateName.getText().trim();
        String SeatNo = txtSeatNo.getText().trim();

//✅ Validation
if (voterId.isEmpty() || partyName.isEmpty() || CandidateName.isEmpty() || SeatNo.isEmpty()) {
    JOptionPane.showMessageDialog(null, "All fields are required.");
    return;
}

//String CandidateName = ""; // You will fetch it from DB or hardcoded for now
//String currentTime = java.time.LocalDateTime.now().toString();

// Prepare data to send: voterid,candidateid,seatno,datetime

String data = voterId + "," + CandidateName + "," + SeatNo + "," + partyName+",";

try {
    ServerConnection.ConnectToServer();
   ServerConnection.out.println("&;" + data);
    String response = ServerConnection.in.readLine();
    JOptionPane.showMessageDialog(null, response);
    ServerConnection.CloseConnection();                             
} catch (Exception e) {
    e.printStackTrace();
    JOptionPane.showMessageDialog(null, "Connection Error: " + e.getMessage());
}

  
    
      
                                                 

    }//GEN-LAST:event_votebtnActionPerformed

    private void txtVoterIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtVoterIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtVoterIDActionPerformed

    private void txtSeatNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSeatNoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSeatNoActionPerformed

    private void txtCandidateNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCandidateNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCandidateNameActionPerformed

    private void txtPartyName3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPartyName3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPartyName3ActionPerformed
 public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
               new vote_cast_scr().setVisible(true);           
}
        });
    }

    /**
     * @param args the command line arguments
     */



    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel VID;
    private javax.swing.JLabel cn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel msg;
    private javax.swing.JLabel pname;
    private javax.swing.JLabel sno;
    private javax.swing.JTextField txtCandidateName;
    private javax.swing.JTextField txtPartyName3;
    private javax.swing.JTextField txtSeatNo;
    private javax.swing.JTextField txtVoterID;
    private javax.swing.JButton votebtn;
    // End of variables declaration//GEN-END:variables

}