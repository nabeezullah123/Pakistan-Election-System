package pakistan.election.system;

public class PakistanElectionSystem {
    public static void main(String[] args) {
       

        login log = new login();
        log.setVisible(true);
             
        
       
        
        
        
    }
}
